


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";



CREATE TABLE `new_students` (
  `FIRST_NAME` varchar(50) NOT NULL,
  `LAST_NAME` varchar(50) NOT NULL,
  `EMAIL` varchar(50) NOT NULL,
  `GENDER` varchar(50) NOT NULL,
  `MOBILE_NO` varchar(50) NOT NULL,
  `DATE_OF_BIRTH` date NOT NULL,
  `HSC_RESULT` varchar(50) NOT NULL,
  `SSC_RESULT` varchar(50) NOT NULL,
  `COURSE` varchar(50) NOT NULL,
  `YEAR` varchar(50) NOT NULL,
  `SEMESTER` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;




INSERT INTO `new_students` (`FIRST_NAME`, `LAST_NAME`, `EMAIL`, `GENDER`, `MOBILE_NO`, `DATE_OF_BIRTH`, `HSC_RESULT`, `SSC_RESULT`, `COURSE`, `YEAR`, `SEMESTER`) VALUES
('', '', '', '', '', '0000-00-00', '', '', '', '', ''),
('', '', '', 'Male', '68477686757', '2021-10-20', 'GPA 5.0', 'GPA 5.0', 'CSE', '2020', 'Summer'),
('', '', '', '', '', '0000-00-00', '', '', '', '', ''),
('khkg', 'fcfh', 'gsghfjh@jggh.com', 'Female', '1234563738482', '2021-10-28', 'GPA 4.0', 'GPA 3.0', 'EEE', '2021', 'Spring');
COMMIT;

